''' Written by Emilie, Maria, Rikke og Helena 2022 ''''

Purposes: 

#1: First, it would be really cool to make the html file show a different layout 
than the initial – to search the limit for this specific script layout. 

#2: Change the “IFC Build - HTML converter” scripts, so additional information
is extracted from the IFC file (the areas of the different rooms and the room 
types as an extension of the previous project) 

 

The HTML-Build-IFC-Converter-main folder, are a gathering of script, that all 
helps the .html file to run! 


See the changes made in the table: 
"HTML-Build-IFC-Converter-main_Group18\img\CHANGES.PNG"
Here we have described the function of the different scripts and the changes we have made